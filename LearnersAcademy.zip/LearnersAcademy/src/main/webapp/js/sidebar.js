$(document).ready(function() {

	$(document).on('click',function(){
		$('.collapse').collapse('hide');
	});

});

